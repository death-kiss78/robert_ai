#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

#define AUDIO_INPUT_SAMPLE_RATE  24000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

//Secțiunea audio IIS
#define AUDIO_I2S_GPIO_MCLK      GPIO_NUM_4  //MCLK
#define AUDIO_I2S_GPIO_BCLK      GPIO_NUM_5  //SCK
#define AUDIO_I2S_GPIO_DIN       GPIO_NUM_6  //DIN
#define AUDIO_I2S_GPIO_WS        GPIO_NUM_7  //LRC
#define AUDIO_I2S_GPIO_DOUT      GPIO_NUM_8  //DOUT
#define AUDIO_CODEC_PA_PIN       GPIO_NUM_1  //PA

//Secțiunea audio IIC
#define AUDIO_CODEC_I2C_NUM      I2C_NUM_0
#define AUDIO_CODEC_I2C_SCL_PIN  GPIO_NUM_15
#define AUDIO_CODEC_I2C_SDA_PIN  GPIO_NUM_16
#define AUDIO_CODEC_ES8311_ADDR  ES8311_CODEC_DEFAULT_ADDR

//Pini Butoane
#define BOOT_BUTTON_GPIO GPIO_NUM_0
#define BUILTIN_LED_GPIO GPIO_NUM_42
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_2
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_3
#define BACKLIGHT_UP_BUTTON_GPIO  GPIO_NUM_NC
#define BACKLIGHT_DOWN_BUTTON_GPIO GPIO_NUM_NC
#define RESET_BUTTON_GPIO         GPIO_NUM_NC

//Secțiunea de afișare a ecranului
#define DISPLAY_BACKLIGHT_PIN GPIO_NUM_45

#define DISPLAY_RST_PIN       GPIO_NUM_NC
#define DISPLAY_SCK_PIN       GPIO_NUM_12
#define DISPLAY_DC_PIN        GPIO_NUM_46
#define DISPLAY_CS_PIN        GPIO_NUM_10
#define DISPLAY_MOSI_PIN      GPIO_NUM_11
#define DISPLAY_MIS0_PIN      GPIO_NUM_13
#define DISPLAY_SPI_SCLK_HZ   (20 * 1000 * 1000)

#define LCD_SPI_HOST          SPI3_HOST

#define LCD_TYPE_ILI9341_SERIAL
#define DISPLAY_WIDTH         320
#define DISPLAY_HEIGHT        240
#define DISPLAY_MIRROR_X      false
#define DISPLAY_MIRROR_Y      false
#define DISPLAY_SWAP_XY       true
#define DISPLAY_INVERT_COLOR  true
#define DISPLAY_RGB_ORDER     LCD_RGB_ELEMENT_ORDER_BGR
#define DISPLAY_OFFSET_X      0
#define DISPLAY_OFFSET_Y      0
#define DISPLAY_BACKLIGHT_OUTPUT_INVERT false
#define DISPLAY_SPI_MODE      0

//Secțiunea SD Card

 #define SD_MMC_CMD GPIO_NUM_40
 #define SD_MMC_CLK GPIO_NUM_38
 #define SD_MMC_D0  GPIO_NUM_39
 #define SD_MMC_D1  GPIO_NUM_41
 #define SD_MMC_D2  GPIO_NUM_48
 #define SD_MMC_D3  GPIO_NUM_47

// A MCP Test: Control a lamp
#define LAMP_GPIO GPIO_NUM_14

// ===================== DHT11 SENSOR =====================
#define DHT11_PIN        GPIO_NUM_21


#endif  // _BOARD_CONFIG_H_
