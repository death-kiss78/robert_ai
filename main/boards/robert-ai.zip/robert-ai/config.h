#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>


// ===================== SD CARD =====================
// Lafvin ESP32-S3-CAM folosește SDMMC pe 1-bit
#define CONFIG_SOC_SDMMC_USE_GPIO_MATRIX 1
#define CONFIG_EXAMPLE_SDMMC_BUS_WIDTH_4 0   // doar 1-bit

// Pinii SDMMC conform pinout-ului LAFVIN ESP32-S3-CAM
#define CONFIG_EXAMPLE_PIN_CLK  GPIO_NUM_39   // SD_CLK
#define CONFIG_EXAMPLE_PIN_CMD  GPIO_NUM_38   // SD_CMD
#define CONFIG_EXAMPLE_PIN_D0   GPIO_NUM_40   // SD_DATA0

/*

// ===================== DHT11 SENSOR =====================
#define DHT11_PIN        GPIO_NUM_2
*/

#define AUDIO_INPUT_SAMPLE_RATE  16000
#define AUDIO_OUTPUT_SAMPLE_RATE 16000

// Dacă utilizați modul Duplex I2S, vă rugăm să comentați următoarea linie.
#define AUDIO_I2S_METHOD_SIMPLEX

#ifdef AUDIO_I2S_METHOD_SIMPLEX

#define AUDIO_I2S_MIC_GPIO_WS   GPIO_NUM_4    // WS,                  (L/R la gnd) 
#define AUDIO_I2S_MIC_GPIO_SCK  GPIO_NUM_5    // SCK
#define AUDIO_I2S_MIC_GPIO_DIN  GPIO_NUM_6    // SD
#define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_7
#define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_15
#define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_16

#else

#define AUDIO_I2S_GPIO_WS GPIO_NUM_4
#define AUDIO_I2S_GPIO_BCLK GPIO_NUM_5
#define AUDIO_I2S_GPIO_DIN  GPIO_NUM_6
#define AUDIO_I2S_GPIO_DOUT GPIO_NUM_7

#endif


#define BUILTIN_LED_GPIO        GPIO_NUM_48
#define BOOT_BUTTON_GPIO        GPIO_NUM_0
#define TOUCH_BUTTON_GPIO       GPIO_NUM_NC
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_NC
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_NC


#define DISPLAY_BACKLIGHT_PIN GPIO_NUM_NC
#define DISPLAY_MOSI_PIN      GPIO_NUM_45
#define DISPLAY_CLK_PIN       GPIO_NUM_3
#define DISPLAY_DC_PIN        GPIO_NUM_47
#define DISPLAY_RST_PIN       GPIO_NUM_21
#define DISPLAY_CS_PIN        GPIO_NUM_14


#define LCD_TYPE_ILI9341_SERIAL
#define DISPLAY_WIDTH   320
#define DISPLAY_HEIGHT  240
#define DISPLAY_MIRROR_X true
#define DISPLAY_MIRROR_Y true
#define DISPLAY_SWAP_XY true
#define DISPLAY_INVERT_COLOR    false
#define DISPLAY_RGB_ORDER  LCD_RGB_ELEMENT_ORDER_BGR
#define DISPLAY_OFFSET_X  0
#define DISPLAY_OFFSET_Y  0
#define DISPLAY_BACKLIGHT_OUTPUT_INVERT false
#define DISPLAY_SPI_MODE 0

// A MCP Test: Control a lamp
#define LAMP_GPIO GPIO_NUM_18

#endif // _BOARD_CONFIG_H_
